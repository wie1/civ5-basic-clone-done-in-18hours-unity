﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Made by Pietari Niinimäki (wie_)
//Use as you wish

//Sorry if some text is in finnish, i tried to make as much of i could in english, but might've gotten carried away
public class Cameracontrols : MonoBehaviour {
    private bool firstpart = false;
    private float scrollamount = 0;
    private bool firsttime = true;
    private worldgen octa;
    private unitscript uscr;
    public bool update = false;
    private Camera cam;
    private GameObject canv;
    public GameObject[] uilist = new GameObject[5];
    private List<GameObject> uiobjlist = new List<GameObject>();
	// Use this for initialization
	void Start () {
        // camera goes to watch player
        gameObject.transform.position = new Vector3(GameObject.Find("octa").GetComponent<unitscript>().unitslist[0].transform.position.x, GameObject.Find("octa").GetComponent<unitscript>().unitslist[0].transform.position.y +6f, GameObject.Find("octa").GetComponent<unitscript>().unitslist[0].transform.position.z - 5.4f);
        canv = GameObject.Find("Canvas");
        cam = GetComponent<Camera>();
        uscr = GameObject.Find("octa").GetComponent<unitscript>();
        octa = GameObject.Find("octa").GetComponent<worldgen>();

        // show tile yields
        for (int e = 0; e < octa.width * octa.height; e++)
        {
            if (uiobjlist.Count == e)
            {
                uiobjlist.Add(new GameObject());
            }
            if (octa.everytile[e].Count > 0)
            {
                var newui = Instantiate(uilist[0]);
                newui.transform.SetParent(canv.transform);
                newui.transform.position = cam.WorldToScreenPoint(octa.everytile[e][0].transform.position);
                uiobjlist[e] = newui;
                if (cam.WorldToViewportPoint(octa.everytile[e][0].transform.position).x > 0f && cam.WorldToViewportPoint(octa.everytile[e][0].transform.position).x < 1f && cam.WorldToViewportPoint(octa.everytile[e][0].transform.position).y > 0f && cam.WorldToViewportPoint(octa.everytile[e][0].transform.position).y < 1f)
                {
                    //print(cam.WorldToScreenPoint(octa.everytile[e][0].transform.position));
                    var uilistnum = 0;

                    if (octa.cloudslist[e].name == "dead")
                    {
                        for (int r = 0; r < octa.everytile[e][0].GetComponent<tilescript>().foodamount; r++)
                        {
                            var newuichild = Instantiate(uilist[3]);
                            newuichild.transform.SetParent(newui.transform);
                            newuichild.transform.position = new Vector2(newui.transform.position.x + octa.everytile[e][0].GetComponent<tilescript>().foodamount * 10 * -1 + 10 + r * 20, newui.transform.position.y + 20);
                        }
                        for (int r = 0; r < octa.everytile[e][0].GetComponent<tilescript>().productionamount; r++)
                        {
                            var newuichild = Instantiate(uilist[2]);
                            newuichild.transform.SetParent(newui.transform);
                            newuichild.transform.position = new Vector2(newui.transform.position.x + octa.everytile[e][0].GetComponent<tilescript>().productionamount * 10 * -1 + 10 + r * 20, newui.transform.position.y);
                        }
                        for (int r = 0; r < octa.everytile[e][0].GetComponent<tilescript>().moneyamount; r++)
                        {
                            var newuichild = Instantiate(uilist[1]);
                            newuichild.transform.SetParent(newui.transform);
                            newuichild.transform.position = new Vector2(newui.transform.position.x + octa.everytile[e][0].GetComponent<tilescript>().moneyamount * 10 * -1 + 10 + r * 20, newui.transform.position.y - 20);
                        }
                    }
                }
            }
        }
    }
	
	// Update is called once per frame
	void Update () {
       
        // infinite x scrolling
        if (gameObject.transform.position.x > octa.width * 2f)
        {
            gameObject.transform.position += new Vector3(0 - gameObject.transform.position.x, 0,0);
        } else if (gameObject.transform.position.x < 0)
        {
            gameObject.transform.position += new Vector3(octa.width * 2f - gameObject.transform.position.x, 0, 0);
        }
        if (gameObject.transform.position.x > octa.width)
        {
            if (!firstpart || firsttime)
            {

                for (int i = 0; i < octa.firstmappart.Count; i++)
                {
                    octa.everytile[octa.firstmappart[i]][0].transform.position += new Vector3(octa.width * 2, 0,0);
                }
                for (int r = 0; r < uscr.unitsidelist.Count; r++)
                {
                    if (uscr.unitsidelist[r] == true)
                    {
                        uscr.unitobjlist[r].transform.position += new Vector3(octa.width * 2, 0, 0);
                    }
                }
                for (int i222 = 0; i222 < octa.cloudsfirstmappart.Count; i222++)
                {
                    octa.cloudslist[octa.cloudsfirstmappart[i222]].transform.position += new Vector3(octa.width * 2, 0, 0);
                }
                
                if (!firstpart)
                {
                    for (int r = 0; r < uscr.unitsidelist.Count; r++)
                    {
                        if (uscr.unitsidelist[r] == false)
                        {
                            uscr.unitobjlist[r].transform.position += new Vector3(octa.width * 2, 0, 0);
                        }
                    }
                    for (int i2 = 0; i2 < octa.secondmappart.Count; i2++)
                    {
                     octa.everytile[octa.secondmappart[i2]][0].transform.position += new Vector3(octa.width * 2 , 0, 0);
                        
                    }
                    
                    for (int i22 = 0; i22 < octa.cloudssecondmappart.Count; i22++)
                    {
                        octa.cloudslist[octa.cloudssecondmappart[i22]].transform.position += new Vector3(octa.width * 2, 0, 0);
                    }
                }
            }
            firstpart = true;
            firsttime = false;
        } else
        {
            if (firstpart || firsttime)
            {

                for (int i2 = 0; i2 < octa.secondmappart.Count; i2++)
                {
                    octa.everytile[octa.secondmappart[i2]][0].transform.position -= new Vector3(octa.width*2, 0, 0);
                }
                for (int r = 0; r < uscr.unitsidelist.Count; r++)
                {
                    if (uscr.unitsidelist[r] == false)
                    {
                        uscr.unitobjlist[r].transform.position -= new Vector3(octa.width * 2, 0, 0);
                    }
                }
                for (int i222 = 0; i222 < octa.cloudssecondmappart.Count; i222++)
                {
                    octa.cloudslist[octa.cloudssecondmappart[i222]].transform.position -= new Vector3(octa.width * 2, 0, 0);
                }
                if (firstpart)
                {
                    for (int i = 0; i < octa.firstmappart.Count; i++)
                    {
                     octa.everytile[octa.firstmappart[i]][0].transform.position -= new Vector3(octa.width* 2, 0, 0);
                    }
                    for (int r = 0; r < uscr.unitsidelist.Count; r++)
                    {
                        if (uscr.unitsidelist[r] == true)
                        {
                            uscr.unitobjlist[r].transform.position -= new Vector3(octa.width * 2, 0, 0);
                        }
                    }
                    for (int i22 = 0; i22 < octa.cloudsfirstmappart.Count; i22++)
                    {
                        octa.cloudslist[octa.cloudsfirstmappart[i22]].transform.position -= new Vector3(octa.width * 2, 0, 0);
                    }
                }
            }
           
            firstpart = false;
            firsttime = false;
        }

        // zooming
        if (Input.GetAxis("Mouse ScrollWheel") < 0)
        {
            gameObject.transform.Translate(0, 0, -1);
            scrollamount -= 0.33f;
        } else if (Input.GetAxis("Mouse ScrollWheel") > 0)
        {
            scrollamount += 0.33f;
            gameObject.transform.Translate(0, 0, 1);
        }

        // moving
            if (Input.GetKey(KeyCode.A))
        {
            gameObject.transform.position += new Vector3(-20 * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.D))
        {
            gameObject.transform.position += new Vector3(20 * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.W) && gameObject.transform.position.z < octa.height * 1.6f + scrollamount)
        {
            gameObject.transform.position += new Vector3(0, 0, 20 * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.S)&& gameObject.transform.position.z > -3.3 + scrollamount)
        {
            gameObject.transform.position += new Vector3(0, 0, -20 * Time.deltaTime);
        }
        if (gameObject.transform.position.z < -3.3f + scrollamount)
        {
            gameObject.transform.position += new Vector3(0,0, -3.3f + scrollamount - gameObject.transform.position.z);
        } else if (gameObject.transform.position.z > octa.height * 1.6f + scrollamount)
        {
            gameObject.transform.position += new Vector3(0, 0, octa.height * 1.6f + scrollamount - gameObject.transform.position.z);
        }

        // updating tile yield positions on screen.
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.D) || (Input.mouseScrollDelta.x + Input.mouseScrollDelta.y) != 0 || update == true)
        {
            update = false;
            for (int e = 0; e < octa.width * octa.height; e++)
            {

                if (octa.everytile[e].Count > 0)
                {
                    if (cam.WorldToViewportPoint(octa.everytile[e][0].transform.position).x > 0f && cam.WorldToViewportPoint(octa.everytile[e][0].transform.position).x < 1f && cam.WorldToViewportPoint(octa.everytile[e][0].transform.position).y > 0f && cam.WorldToViewportPoint(octa.everytile[e][0].transform.position).y < 1f)
                    {
                        if (uiobjlist[e].transform.childCount == 0 && (octa.everytile[e][0].GetComponent<tilescript>().foodamount > 0|| octa.everytile[e][0].GetComponent<tilescript>().moneyamount > 0 || octa.everytile[e][0].GetComponent<tilescript>().productionamount > 0) )
                        {
                            if (octa.cloudslist[e].name == "dead")
                            {
                                for (int r = 0; r < octa.everytile[e][0].GetComponent<tilescript>().foodamount; r++)
                                {
                                    var newuichild = Instantiate(uilist[3]);
                                    newuichild.transform.SetParent(uiobjlist[e].transform);
                                    newuichild.transform.position = new Vector2(uiobjlist[e].transform.position.x + octa.everytile[e][0].GetComponent<tilescript>().foodamount * 10 * -1 + 10 + r * 20, uiobjlist[e].transform.position.y + 20);
                                }


                                for (int r = 0; r < octa.everytile[e][0].GetComponent<tilescript>().productionamount; r++)
                                {
                                    var newuichild = Instantiate(uilist[2]);
                                    newuichild.transform.SetParent(uiobjlist[e].transform);
                                    newuichild.transform.position = new Vector2(uiobjlist[e].transform.position.x + octa.everytile[e][0].GetComponent<tilescript>().productionamount * 10 * -1 + 10 + r * 20, uiobjlist[e].transform.position.y);
                                }

                                for (int r = 0; r < octa.everytile[e][0].GetComponent<tilescript>().moneyamount; r++)
                                {
                                    var newuichild = Instantiate(uilist[1]);
                                    newuichild.transform.SetParent(uiobjlist[e].transform);
                                    newuichild.transform.position = new Vector2(uiobjlist[e].transform.position.x + octa.everytile[e][0].GetComponent<tilescript>().moneyamount * 10 * -1 + 10 + r * 20, uiobjlist[e].transform.position.y - 20);
                                }
                            }
                        }
                        uiobjlist[e].transform.position = cam.WorldToScreenPoint(octa.everytile[e][0].transform.position);
                        //print(cam.WorldToScreenPoint(octa.everytile[e][0].transform.position));
                        /*var newui = Instantiate(uilist[0]);
                        newui.transform.SetParent(canv.transform);
                        newui.transform.position = cam.WorldToScreenPoint(octa.everytile[e][0].transform.position);
                        uiobjlist.Add(newui);*/
                    }
                    else
                    {
                        for (int u = 0; u < uiobjlist[e].transform.childCount; u++)
                        {
                            Destroy(uiobjlist[e].transform.GetChild(u).gameObject);
                        }

                    }
                }
            }
        }
        
    }
}
