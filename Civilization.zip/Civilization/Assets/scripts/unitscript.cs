﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Made by Pietari Niinimäki (wie_)
//Use as you wish

//Sorry if some text is in finnish, i tried to make as much of i could in english, but might've gotten carried away
public class unitscript : MonoBehaviour {
    public GameObject[] unitobjlist = new GameObject[5];
    public List<GameObject> unitslist = new List<GameObject>();
    private List<int> unitposlist = new List<int>();
    public List<bool> unitsidelist = new List<bool>();
	// Use this for initialization
	void Start () {
		
	}
	public void spawn(Vector2 pos, int posnum)
    {
        var settlerunit = Instantiate(unitobjlist[0], new Vector3(pos.x, GetComponent<worldgen>().elevation[posnum] / 4 + 0.71f, pos.y), Quaternion.identity);
        unitslist.Add(settlerunit);
        unitposlist.Add(posnum);
        updatepos(posnum, unitslist.Count - 1, new Vector3());
        if (pos.x < GetComponent<worldgen>().width)
        {
            unitsidelist.Add(false);
        } else
        {
            unitsidelist.Add(true);
        }
    }
    private void updatepos(int pos, int id,Vector3 pos2d)
        
    {if (pos == -1)
        {
            var offsetnum = 0;
            if (Mathf.FloorToInt(unitposlist[0] / GetComponent<worldgen>().width) % 2 == 0)
            {
                offsetnum = 1;
            }
            var neighbors = GetComponent<worldgen>().findneighbors(unitposlist[0], GetComponent<worldgen>().width, offsetnum);
            for (int i = 0; i < neighbors.Length; i++)
            {
                if (neighbors[i] > 0 && neighbors[i] < GetComponent<worldgen>().width * GetComponent<worldgen>().height)
                {
                    if (GetComponent<worldgen>().everytile[neighbors[i]][0].transform.position == pos2d)
                    {
                        unitposlist[0] = neighbors[i];
                        pos = neighbors[i];
                        unitslist[0].transform.position = new Vector3(pos2d.x, GetComponent<worldgen>().elevation[pos] / 4 + 0.71f, pos2d.y);
                    }
                }
            }
        }else
        {
            unitposlist[0] = pos;
            GetComponent<worldgen>().clearclouds(pos);
        }
        print(pos);
        
    }
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(1))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit, 100.0f))
            {
                if (hit.transform.gameObject.name == "tile")
                {
                    updatepos(hit.transform.gameObject.GetComponent<tilescript>().weirdnum, 0, hit.transform.gameObject.transform.position);
                    unitslist[0].transform.position = new Vector3(hit.transform.gameObject.transform.position.x, GetComponent<worldgen>().elevation[hit.transform.gameObject.GetComponent<tilescript>().weirdnum] / 4 + 0.71f, hit.transform.gameObject.transform.position.z);
                }
            }
        }
    }
}
