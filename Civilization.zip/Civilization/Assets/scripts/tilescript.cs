﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Made by Pietari Niinimäki (wie_)
//Use as you wish

//Sorry if some text is in finnish, i tried to make as much of i could in english, but might've gotten carried away

    // every hexagon has this script.
public class tilescript : MonoBehaviour {
    private bool[] riverlocs = new bool[6];

    //these are information of the tile, mostly used for calculating tile yield.
    public int res;
    public int natobj;
    public int elevation;
    public bool freshwater;
    public int tiletype;
    public bool coastal;
    public int foodamount = 0;
    public int productionamount = 0;
    public int moneyamount = 0;

    //tile index
    public int weirdnum = 0;

    //the river model
    public GameObject river;
	// Use this for initialization
	void Start () {
		
	}

    // updates tile yield.
    public void updateres()
    {
        productionamount = 0;
        foodamount = 0;
        moneyamount = 0;
        switch (tiletype)
        {
            case 0:
                 foodamount += 2;
                break;
            case 2:
                foodamount += 2;
                break;
            case 6:
                foodamount += 1;
                productionamount += 1;
                break;
            case 7:
                foodamount += 1;

                break;
        }
          if(freshwater)
          {
              foodamount += 1;
              if (tiletype == 5)
              {
                  foodamount += 2;
              }
          }
        if (elevation == 2)
        {
            productionamount = 2;
            if (foodamount > 0)
            {
                foodamount -= 1;
            }
        }
        else if (elevation == 4)
        {
            foodamount = 0;
            productionamount = 0;
            moneyamount = 0;
        }
        switch (natobj)
        {
            case 2:
                
                    productionamount = 0;
                
                foodamount = 3;
                break;
            case 3:
                productionamount = 1;
                foodamount = 1;
                break;

        }
        if (natobj != 2 && natobj != 3)
        {
            switch (res)
            {
                case 1:
                    moneyamount += 2;
                    foodamount -= 2;
                    productionamount += 1;
                    break;
                case 2:
                    foodamount += 1;
                    productionamount += 1;
                    moneyamount += 1;
                    break;

            }

        }
        if (foodamount < 0)
        {
            foodamount = 0;
        }
        
        /*
        switch (tiletype)
        {
            case 0:
                foodamount += 2;
                    break;
            case 2:
                foodamount += 2;
                break;
            case 6:
                foodamount += 1;
                productionamount += 1;
                break;
            case 7:
                foodamount += 1;
                break;
        }
        if (elevation == 2)
        {
            productionamount = 2;
            if (foodamount > 0)
            {
                foodamount -= 1;
            }
        } else if (elevation == 4)
        {
            foodamount = 0;
            productionamount = 0;
            moneyamount = 0;
        }
        switch (natobj)
        {
            case 2:
                productionamount -= 2;
                if (productionamount < 0)
                {
                    productionamount = 0;
                }
                foodamount += 2;
                break;
            case 3:
                productionamount += 2;
                foodamount = 1;
                break;

        }
        if (foodamount > 5)
        {
            foodamount = 5;
        }
        if (productionamount > 5)
        {
            productionamount = 5;
        }
        if (tiletype == 8)
        {
            foodamount = 0;
        }*/
    }

    //"calculates" river path (confusing and weird)
    public int findriverroute(int na, int nas, int nb, int riverlength, float ypos)
    {
        var riverroute = new bool[6];
        var endcorner = 0;
        if (ypos == -1)
        {
            ypos = 0;
        }
        if (ypos == 2)
        {
            ypos = 0.34f;
        }
        if (ypos == 4)
        {
            ypos = 0.34f;
        }
        //check which corner start river touching
        var corner = 0;
        if (nas == -1)
         {
             var startpossibilities = new int[2];
             switch (na)
             {
                 case 0:
                     startpossibilities[0] = 5;
                     startpossibilities[1] = 1;
                     break;
                 case 1:
                     startpossibilities[0] = 0;
                     startpossibilities[1] = 5;
                     break;
                 case 2:
                     startpossibilities[0] = 3;
                     startpossibilities[1] = 1;
                     break;
                 case 3:
                     startpossibilities[0] = 4;
                     startpossibilities[1] = 2;
                     break;
                 case 4:
                     startpossibilities[0] = 5;
                     startpossibilities[1] = 3;
                     break;
                 case 5:
                     startpossibilities[0] = 0;
                     startpossibilities[1] = 4;
                     break;
             }
             nas = startpossibilities[Random.Range(0,2)];
         } else
         {/*
             switch (na)
             {
                 case 0:
                    switch (nas)
                    {
                        case 0:
                            nas = 5;
                            break;
                        case 1:
                            nas = 0;
                            break;
                        case 2:
                            nas = 1;
                            break;
                        case 3:
                            nas = 2;
                            break;
                        case 4:
                            nas = 3;
                            break;
                        case 5:
                            nas = 4;
                            break;
                    }


                     break;
                 case 1:
                    switch (nas)
                    {
                        case 0:
                            nas = 1;
                            break;
                        case 1:
                            nas = 0;
                            break;
                        case 2:
                            nas = 5;
                            break;
                        case 3:
                            nas = 4;
                            break;
                        case 4:
                            nas = 3;
                            break;
                        case 5:
                            nas = 2;
                            break;
                    }


                    break;
                 case 2:
                    switch (nas)
                    {
                        case 0:
                            nas = 3;
                            break;
                        case 1:
                            nas = 4;
                            break;
                        case 2:
                            nas = 5;
                            break;
                        case 3:
                            nas = 0;
                            break;
                        case 4:
                            nas = 1;
                            break;
                        case 5:
                            nas = 2;
                            break;
                    }
                    break;
                 case 3:
                    switch (nas)
                    {
                        case 0:
                            nas = 3;
                            break;
                        case 1:
                            nas = 2;
                            break;
                        case 2:
                            nas = 1;
                            break;
                        case 3:
                            nas = 0;
                            break;
                        case 4:
                            nas = 5;
                            break;
                        case 5:
                            nas = 4;
                            break;
                    }

                    nas = 0;
                     break;
                 case 4:
                    switch (nas)
                    {
                        case 0:
                            nas = 2;
                            break;
                        case 1:
                            nas = 1;
                            break;
                        case 2:
                            nas = 0;
                            break;
                        case 3:
                            nas = 5;
                            break;
                        case 4:
                            nas = 4;
                            break;
                        case 5:
                            nas = 3;
                            break;
                    }
                     break;
                 case 5:
                    switch (nas)
                    {
                        case 0:
                            nas = 4;
                            break;
                        case 1:
                            nas = 3;
                            break;
                        case 2:
                            nas = 2;
                            break;
                        case 3:
                            nas = 1;
                            break;
                        case 4:
                            nas = 0;
                            break;
                        case 5:
                            nas = 5;
                            break;
                    }
                     break;


             }*/
         }

         //print("start" + na + "s" + nas + "s" + nb + "length" + riverlength);
         //print(na + "t" + gameObject.transform.position);
        /*
         switch (na)
         {
             case 0:
                 if (nas == 0)
                 {
                     corner = 5;
                 } else if (nas == 2)
                 {
                     corner = 2;
                 }
                 break;
             case 1:
                 if (nas == 3)
                 {
                     corner = 3;
                 }
                 else if (nas == 1)
                 {
                     corner = 0;
                 }
                 break;
             case 2:
                 if (nas == 4)
                 {
                     corner = 4;
                 }
                 else if (nas == 2)
                 {
                     corner = 1;
                 }
                 break;
             case 3:
                 if (nas == 5)
                 {
                     corner = 5;
                 }
                 else if (nas == 3)
                 {
                     corner = 2;
                 }
                 break;
             case 4:
                 if (nas == 0)
                 {
                     corner = 0;
                 }
                 else if (nas == 4)
                 {
                     corner = 3;
                 }
                 break;
             case 5:
                 if (nas == 1)
                 {
                     corner = 1;
                 }
                 else if (nas == 5)
                 {
                     corner = 4;
                 }
                 break;
         }
        // print("starty" + corner);
         var lessergoal = nb - 1;
         if (nb - 1 < 0)
         {
             lessergoal = 5;
         }

         var nearestgoal = distto(corner, lessergoal);
         endcorner = lessergoal;
if (Mathf.Abs(distto(corner,nb)) < Mathf.Abs(nearestgoal))
         {
             nearestgoal = distto(corner, nb);
             endcorner = nb;

         } 
         // print("starty" + endcorner + "y" + nearestgoal);
         // print(corner + "test" + na + "test" + lessergoal);
         // riverroute[nas] = true;
           if (nearestgoal < 0)
           {
               if (nas - 1 > -1)
               {
                  // riverroute[nas - 1] = true;
                   print(corner + "t" + nearestgoal + "t" + (nas - 1));
               } else
               {
                //   riverroute[5] = true;
                   print(corner + "t" + nearestgoal + "t" + 5);
               }
           } else
           {
               if (nas + 1 < 6)
               {
                 //  riverroute[nas + 1] = true;
                   print(corner + "t" + nearestgoal + "t" + (nas + 1));
               }
               else
               {
                  // riverroute[0] = true;
                   print(corner + "t" + nearestgoal + "t" + 0);
               }
           }
           
        print(nas);*/
          //riverroute[endcorner] = true;
        switch (na)
         {
             case 4:
                //  if (nb != 2)
                //  {
                if (nb != 1 && nb != 2)
                {
                    riverroute[0] = true;
                }
              //  }
                if (nb != 2)
                {
                    riverroute[1] = true;
                }
               // if (nb != 1)
              //  {
                    riverroute[2] = true;
              //  }
                 break;
             case 5:

                //    if (nb != 2 && nb != 3 && nb != 1)
                //  {
                if (nb != 3 && nb != 2)
                {
                    riverroute[1] = true;
                }
              //  }
                if (nb != 3)
                {
                    riverroute[2] = true;
               }
                    riverroute[3] = true;
                       
                 break;
            case 0:
                if (nb != 3 && nb != 4)
                {
                    riverroute[2] = true;
                }
                if (nb != 4)
                {
                    riverroute[3] = true;
                }
              //  if (nb != 3)
               // {
                    riverroute[4] = true;
                //}
              //  }
                break;
            case 1:

                if (nb != 4 && nb != 5)
                {
                    riverroute[3] = true;
                }
                if (nb != 5)
                {
                    riverroute[4] = true;
                }
               // if (nb != 4 && nb != 5)
                //{
                    riverroute[5] = true;
                //}
                break;
            case 2:
                if (nb != 0&&nb != 5)
                {
                    riverroute[4] = true;
                }
                //  if (nb != 0)
                //  {
                if (nb != 0)
                {
                    riverroute[5] = true;
                }
              //  }
              //  if (nb != 5 && nb != 0)
              //  {
                    riverroute[0] = true;
              //  }

                break;
            case 3:
                if (nb != 0 && nb != 1)
                {
                    riverroute[5] = true;
                }
                if (nb != 1)
                {

                    riverroute[0] = true;
                }
                
                    riverroute[1] = true;
                
                break;


        }
        
        //riverroute[nas] = true;
        //print("Joki lähtee pisteestä: " + na + "josta kohti: " + nb + "joen pituus: " + riverlength + "coords" + gameObject.transform.position);
        // print("Eli reitti on 0:" + riverroute[0] + " 1:" + riverroute[1] + " 2:" + riverroute[2] + " 3:" + riverroute[3] + " 4:" + riverroute[4] + " 5:" + riverroute[5]);
        var jokipalojenmäärä = 0;
        for (int s = 0; s < riverroute.Length; s++)
        {
           
            if (riverroute[s] == true && riverlocs[s] == false)
            {
                freshwater = true;
                riverlocs[s] = true;
                var riverpiece = Instantiate(river, gameObject.transform.position, Quaternion.Euler(90, 60 * s +60 + 60, 0));
              //  print(elevation);
               riverpiece.transform.Translate(0, 0,-0.1f - ypos);
                riverpiece.name = na.ToString() + "nb" + nb.ToString() + "s" + s.ToString();
                riverpiece.transform.localScale = new Vector3(1.16f, 1.16f, -1.16f);
                riverpiece.transform.SetParent(gameObject.transform);
            }
        }
        updateres();
        return endcorner;
    }

    // this isn't even used anymore
    private int distto(int from, int to)
    {
        var dist = 0;

        switch(from)
        {
            case 0:
                switch(to)
                {
                    case 0:
                        dist = 0;
                        break;
                    case 1:
                        dist = 1;
                        break;
                    case 2:
                        dist = 2;
                        break;
                    case 3:
                        dist = 3;
                        break;
                    case 4:
                        dist = -2;
                        break;
                    case 5:
                        dist = -1;
                        break;
                }
                break;
            case 1:
                switch (to)
                {
                    case 0:
                        dist = -1;
                        break;
                    case 1:
                        dist = 0;
                        break;
                    case 2:
                        dist = 1;
                        break;
                    case 3:
                        dist = 2;
                        break;
                    case 4:
                        dist = 3;
                        break;
                    case 5:
                        dist = -2;
                        break;
                }
                break;
            case 2:
                switch (to)
                {
                    case 0:
                        dist = -2;
                        break;
                    case 1:
                        dist = -1;
                        break;
                    case 2:
                        dist = 0;
                        break;
                    case 3:
                        dist = 1;
                        break;
                    case 4:
                        dist = 2;
                        break;
                    case 5:
                        dist = 3;
                        break;
                }
                break;
            case 3:
                switch (to)
                {
                    case 0:
                        dist = 3;
                        break;
                    case 1:
                        dist = -2;
                        break;
                    case 2:
                        dist = -1;
                        break;
                    case 3:
                        dist = 0;
                        break;
                    case 4:
                        dist = 1;
                        break;
                    case 5:
                        dist = 2;
                        break;
                }
                break;
            case 4:
                switch (to)
                {
                    case 0:
                        dist = 2;
                        break;
                    case 1:
                        dist = 3;
                        break;
                    case 2:
                        dist = -2;
                        break;
                    case 3:
                        dist = -1;
                        break;
                    case 4:
                        dist = 0;
                        break;
                    case 5:
                        dist = 1;
                        break;
                }
                break;
            case 5:
                switch (to)
                {
                    case 0:
                        dist = 1;
                        break;
                    case 1:
                        dist = 2;
                        break;
                    case 2:
                        dist = 3;
                        break;
                    case 3:
                        dist = -2;
                        break;
                    case 4:
                        dist = -1;
                        break;
                    case 5:
                        dist = 0;
                        break;
                }
                break;
        }
        return dist;
    }
	// Update is called once per frame
	void Update () {
		
	}
}
