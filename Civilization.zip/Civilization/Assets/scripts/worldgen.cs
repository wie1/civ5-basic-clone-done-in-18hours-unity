﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Made by Pietari Niinimäki (wie_)
//Use as you wish

//Sorry if some text is in finnish, i tried to make as much of i could in english, but might've gotten carried away


public class worldgen : MonoBehaviour {
    //This is a list of all the tile(hexagon) types, for example, if the 300th object in this list (tilelist[299]) is 8, that means that the 300th hexagon is a snow tile.
    //0 is grasslands tile, 1 is water tile, 3 is a tile that marks land, 4 is a tile that marks water(basically same as 1), 4 is a void tile, if an object in this list is 4, that means it has no information.
    //5 is desert tile, 6 is plains tile, 7 is tundra tile, 8 is snow tile. 9 is hill, 10 is mountain.
    private List<int> tilelist = new List<int>();

    //i will explain later in code
    private List<int> growlist1 = new List<int>();

    //this is a list like tilelist, but for natural objects such as forest and jungle.
    private List<int> natobjlist = new List<int>();

    //these variables are given the maps width and height so that other scripts can access them.
    public int width = 0;
    public int height = 0;

    //this is a list of every tile object that has been instantiated. For example everytile[300][0] corresponds to a hexagon somewhere, if tilelist[300] is not water
    public List<List<GameObject>> everytile = new List<List<GameObject>>();

    //this tells the position of natural objects in other arrays, so not the coordinates, but the index.
    private List<int> natobjposlist = new List<int>();

    // these are for infinite horizontal scrolling, firstmappart contains the indexes of the first 1/4 of the map, second contains the indexes of the last 1/4 of the map
    public List<int> firstmappart = new List<int>();
    public List<int> secondmappart = new List<int>();

    // this is the same but for clouds (black tiles on top of land)
    public List<int> cloudsfirstmappart = new List<int>();
    public List<int> cloudssecondmappart = new List<int>();

    // this is like tilelist or natobjlist, but for resources (gold and wine)
    private List<int> reslist = new List<int>();

    // this tells, in what index the player will spawn
    public int spawnpoint = 0;

    // this list contains all possible resource prefabs
    public GameObject[] resobjlist = new GameObject[2];

    //i will explain these "growlists" later
    private List<int> resgrowlist = new List<int>();

    // river generation is confusing, i'll try to explain later
    private List<int> riverlist = new List<int>();

    // this list contains all possible natural objects (forest,jungle)
    public GameObject[] natobjs = new GameObject[20];

    // this is like everytile list, but for clouds
    public List<GameObject> cloudslist = new List<GameObject>();

    private int treetype = 0;

    // this list is like tilelist, but it tells if the hexagon has a hill or a mountain or neither
    public List<int> elevation = new List<int>();
    private List<int> elevationgrowlist = new List<int>();

    // this list contains all possible hexagon gameobjects (like desert, snow)
    public GameObject[] tileobjs = new GameObject[20];

    // coordinates for tiles, used later
    private float tilexcoord = 0;
    private float tilezcoord = 0;

    // misleading name, actually tells if the line is an offset line (in hex grids some lines are offset)
    private bool longrow = false;


    private int growlistorigamount = 0;
    // Use this for initialization
    void Start() {
        generateworld(80, 60);
    }
    // this function returns the indexes of hexagons near pos.
    public int[] findneighbors(int pos, int w, int offset)
    {
        var neighbors = new int[6];
        if (offset == 0)
        {
            if (Mathf.FloorToInt((pos - w - 1) / w) != Mathf.FloorToInt((pos - w) / w))
            {
                neighbors[4] = pos - 1;
            }
            else
            {
                neighbors[4] = pos - w - 1;
            }
            neighbors[3] = pos - w;
            if (Mathf.FloorToInt((pos - 1) / w) != Mathf.FloorToInt((pos) / w))
            {
                neighbors[5] = pos - 1 + w;
            }
            else
            {
                neighbors[5] = pos - 1;
            }
            if (Mathf.FloorToInt((pos + 1) / w) != Mathf.FloorToInt((pos) / w))
            {
                neighbors[2] = pos + 1 - w;
            }
            else
            {
                neighbors[2] = pos + 1;
            }
            if (Mathf.FloorToInt((pos + w - 1) / w) != Mathf.FloorToInt((pos + w) / w))
            {
                neighbors[0] = pos + w * 2 - 1;
            }
            else
            {
                neighbors[0] = pos + w - 1;
            }
            neighbors[1] = pos + w;
        } else if (offset == 1)
        {
            neighbors[4] = pos - w;
            if (Mathf.FloorToInt((pos - w + 1) / w) != Mathf.FloorToInt((pos - w) / w))
            {
                neighbors[3] = pos - w * 2 + 1;
            }
            else
            {
                neighbors[3] = pos - w + 1;
            }
            if (Mathf.FloorToInt((pos - 1) / w) != Mathf.FloorToInt((pos) / w))
            {
                neighbors[5] = pos - 1 + w;
            }
            else
            {
                neighbors[5] = pos - 1;
            }
            if (Mathf.FloorToInt((pos + 1) / w) != Mathf.FloorToInt((pos) / w))
            {
                neighbors[2] = pos + 1 - w;
            }
            else
            {
                neighbors[2] = pos + 1;
            }
            neighbors[0] = pos + w;
            if (Mathf.FloorToInt((pos + w + 1) / w) != Mathf.FloorToInt((pos + w) / w))
            {
                neighbors[1] = pos + 1;
            }
            else
            {
                neighbors[1] = pos + w + 1;
            }
        }

        return neighbors;
    }

    // this generates the world, is given w and h, width and height
    private void generateworld(int w, int h)
    {
        height = h;
        width = w;

        // here it puts few sea and land points on the map
        tilexcoord = 0.5f;
        tilezcoord = 0;
        for (int i = 0; i < w * h; i++)
        {

            if (Random.Range(0, 1000) < 5)
            {
                if (Random.Range(0, 4) == 1)
                {
                    tilelist.Add(0);
                }
                else
                {
                    tilelist.Add(1);
                }
                growlist1.Add(i);
            }
            else
            {
                tilelist.Add(4);
            }




        }

        // here each of those points "grow", it's neighbors become the same tile that it was, if they have not been assigned a sea or land point, basically the sea and land hexagons grow until they meet
        for (int d = 0; d < 30; d++)
        {

            growlistorigamount = growlist1.Count;
            for (int q = 0; q < growlistorigamount; q++)
            {
                if (tilelist[growlist1[q]] < 2)
                {
                    var offsetnum = 0;
                    if (Mathf.FloorToInt(growlist1[q] / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    var neighbors = findneighbors(growlist1[q], w, offsetnum);

                    for (int f = 0; f < neighbors.Length; f++)
                    {
                        if (neighbors[f] > 0 && neighbors[f] < w * h)
                        {

                            if (tilelist[neighbors[f]] == 4)
                            {

                                tilelist[neighbors[f]] = tilelist[growlist1[q]];

                                // growlist1.RemoveAt(q);
                                growlist1.Add(neighbors[f]);
                            }

                        }
                    }

                    if (tilelist[growlist1[q]] == 0)
                    {
                        tilelist[growlist1[q]] = 2;
                    }
                    else if (tilelist[growlist1[q]] == 1)
                    {
                        tilelist[growlist1[q]] = 3;
                    }
                }
                // growlist1.RemoveAt(q);
            }

        }
        growlist1.Clear();


        // to make the terrain more interesting, points are added similarly, but land points are only put in places where there is land, and sea point where there is sea.
        for (int t = 0; t < w * h; t++)
        {
            riverlist.Add(-2);
            if (Random.Range(0, 10) < 1)
            {
                growlist1.Add(t);
                if (tilelist[t] == 2)
                {
                    if (Random.Range(0, 10) != 1)
                    {
                        tilelist[t] = 0;

                    }
                    else
                    {
                        tilelist[t] = 1;
                    }
                }
                else if (tilelist[t] == 3)
                {
                    if (Random.Range(0, 10) != 1)
                    {
                        tilelist[t] = 1;
                    }
                    else
                    {
                        tilelist[t] = 2;
                    }
                }
            }
            else
            {
                tilelist[t] = 4;
            }
        }

        // now the new points "grow" until they meet one another
        for (int d2 = 0; d2 < 10; d2++)
        {

            growlistorigamount = growlist1.Count;
            for (int q = 0; q < growlistorigamount; q++)
            {
                if (tilelist[growlist1[q]] < 2)
                {
                    var offsetnum = 0;
                    if (Mathf.FloorToInt(growlist1[q] / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    var neighbors = findneighbors(growlist1[q], w, offsetnum);

                    for (int f = 0; f < neighbors.Length; f++)
                    {
                        if (neighbors[f] > 0 && neighbors[f] < w * h)
                        {

                            if (tilelist[neighbors[f]] == 4)
                            {

                                tilelist[neighbors[f]] = tilelist[growlist1[q]];

                                // growlist1.RemoveAt(q);
                                growlist1.Add(neighbors[f]);
                            }

                        }
                    }

                    if (tilelist[growlist1[q]] == 0)
                    {
                        tilelist[growlist1[q]] = 2;
                    }
                    else if (tilelist[growlist1[q]] == 1)
                    {
                        tilelist[growlist1[q]] = 3;
                    }
                }
                // growlist1.RemoveAt(q);
            }

        }
        growlist1.Clear();

        // i don't remember, but i'd guess that this basically returns the last action, so adds randomness by adding points in some places
        for (int td = 0; td < w * h; td++)
        {
            riverlist.Add(-2);
            if (Random.Range(0, 10) < 1)
            {
                growlist1.Add(td);
                if (tilelist[td] == 2)
                {
                    if (Random.Range(0, 10) != 1)
                    {
                        tilelist[td] = 0;

                    }
                    else
                    {
                        tilelist[td] = 1;
                    }
                }
                else if (tilelist[td] == 3)
                {
                    if (Random.Range(0, 10) != 1)
                    {
                        tilelist[td] = 1;
                    }
                    else
                    {
                        tilelist[td] = 2;
                    }
                }
            }
            else
            {
                tilelist[td] = 4;
            }
        }

        //those points grow.
        for (int dt2 = 0; dt2 < 10; dt2++)
        {

            growlistorigamount = growlist1.Count;
            for (int q = 0; q < growlistorigamount; q++)
            {
                if (tilelist[growlist1[q]] < 2)
                {
                    var offsetnum = 0;
                    if (Mathf.FloorToInt(growlist1[q] / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    var neighbors = findneighbors(growlist1[q], w, offsetnum);

                    for (int f = 0; f < neighbors.Length; f++)
                    {
                        if (neighbors[f] > 0 && neighbors[f] < w * h)
                        {

                            if (tilelist[neighbors[f]] == 4)
                            {

                                tilelist[neighbors[f]] = tilelist[growlist1[q]];

                                // growlist1.RemoveAt(q);
                                growlist1.Add(neighbors[f]);
                            }

                        }
                    }

                    if (tilelist[growlist1[q]] == 0)
                    {
                        tilelist[growlist1[q]] = 2;
                    }
                    else if (tilelist[growlist1[q]] == 1)
                    {
                        tilelist[growlist1[q]] = 3;
                    }
                }
                // growlist1.RemoveAt(q);
            }

        }
        growlist1.Clear();
        var island = true;
        var coastal = false;
        var land = false;
        var coasts = new List<int>();
        //here points are added for terrain elevation and resources.
        for (int t = 0; t < w * h; t++)
        {
            reslist.Add(0);
            elevation.Add(0);
            if (Random.Range(0, 20) == 0)
            {
                elevation[t] = -1;
                elevationgrowlist.Add(t);
            }
            else if (Random.Range(0, 30) == 1)
            {
                elevation[t] = 1;
                elevationgrowlist.Add(t);
            }
            if (Random.Range(0, 25) == 1)
            {
                resgrowlist.Add(t);
                if (Random.Range(0, 2) == 1)
                {
                    reslist[t] = 1;
                }
                else
                {
                    reslist[t] = 2;
                }
            }
            if (Random.Range(0, 2) == 1)
            {
                reslist[t] = -1;
            }


            // here points are added for biomes and natural objects
            var randomnessmp = 8;
            if (Random.Range(0, 10) < 2)
            {

                if (tilelist[t] == 2)
                {
                    growlist1.Add(t);
                    if (Random.Range(0, 6) < ((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 4f / (h / 100f))) * -1f) - (h / 3) + Random.Range(h / randomnessmp * -1, h / randomnessmp))
                    {
                        tilelist[t] = 0;
                        if (Random.Range(0, 10) <= 6)
                        {
                            natobjlist.Add(2);
                        }
                        else
                        {
                            natobjlist.Add(0);
                        }

                    }
                    else if (Random.Range(0, 6) < ((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 4f / (h / 100f))) * -1f) - (h / 5f) + Random.Range(h / randomnessmp * -1, h / randomnessmp))
                    {
                        tilelist[t] = 6;
                        if (Random.Range(0, 10) <= 4)
                        {
                            natobjlist.Add(3);
                        }
                        else
                        {
                            natobjlist.Add(0);
                        }
                    }
                    else if (Random.Range(0, 6) < (((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 4f / (h / 100f))) * -1f) - (h / 8f) - (((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 4f / (h / 100f))) * -1f) - (h / 8f))) * 10f + (((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 4f / (h / 100f))) * -1f) - (h / 8f)) + Random.Range(h / randomnessmp * -1, h / randomnessmp))
                    {
                        tilelist[t] = 5;
                    }

                    else if (Random.Range(0, 6) < ((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 2f / (h / 100f))) * -1f) * 2f - (h / 1.5f) + Random.Range(h / randomnessmp * -1, h / randomnessmp))
                    {
                        tilelist[t] = 6;
                        if (Random.Range(0, 10) <= 4)
                        {
                            natobjlist.Add(3);
                        }
                        else
                        {
                            natobjlist.Add(0);
                        }
                    }

                    else if (Random.Range(0, 4) < ((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 2f / (h / 100f))) * -1f) * 2f - (h / 3f) + Random.Range(h / randomnessmp * -1, h / randomnessmp))
                    {
                        if (Random.Range(0, 2) == 1)
                        {
                            tilelist[t] = 0;
                        }
                        else
                        {
                            tilelist[t] = 6;
                        }
                        if (Random.Range(0, 10) <= 5)
                        {

                            natobjlist.Add(3);
                        }
                        else
                        {
                            natobjlist.Add(0);
                        }

                    }

                    else if (Random.Range(0, 2) < ((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 2f / (h / 100f))) * -1f) * 2f + Random.Range(h / randomnessmp * -1, h / randomnessmp))
                    {
                        tilelist[t] = 7;
                        if (Random.Range(0, 10) <= 7)
                        {
                            natobjlist.Add(3);
                        }
                        else
                        {
                            natobjlist.Add(0);
                        }

                    }

                    else if (Random.Range(0, 2) < ((Mathf.Abs(Mathf.FloorToInt(t / w) - h / 2f) / (h / 100f) - (h / 2f / (h / 100f))) * -1f) * 2f + (h / 2f) + Random.Range(h / randomnessmp * -1, h / randomnessmp))
                    {
                        tilelist[t] = 8;

                    }

                    else
                    {
                        tilelist[t] = 6;
                    }
                }
            }
            else
            {
                //tilelist[t] = 4;
            }
            if (tilelist[t] != 3 && tilelist[t] != 1 && tilelist[t] != 4)
            {

                var offsetnum = 0;
                if (Mathf.FloorToInt(t / w) % 2 == 0)
                {
                    offsetnum = 1;
                }
                var neighbors = findneighbors(t, w, offsetnum);
                coasts.Clear();
                coastal = false;
                island = true;
                for (int f = 0; f < neighbors.Length; f++)
                {

                    if (neighbors[f] > 0 && neighbors[f] < w * h)
                    {
                        //  print(neighbors[f]);
                        if (tilelist[neighbors[f]] == 3 || tilelist[neighbors[f]] == 1 || tilelist[neighbors[f]] == 4)
                        {

                            coastal = true;
                            coasts.Add(neighbors[f]);
                        }
                        else
                        {
                            island = false;
                        }
                    }
                }

                if (coastal == true && island == false)
                {
                    // if the tile we are now inspecting is not an island and is coast, a point for the river to grow from is added in the water.
                    if (Random.Range(0, 100) < 10)
                    {
                        riverlist[t] = 0;
                        // tilelist[t] = 8;
                        //print(coasts[0] + "test" + d3);
                        riverlist[coasts[Random.Range(0, coasts.Count)]] = -1;


                    }
                }
            }
            if (natobjlist.Count <= t)
            {
                natobjlist.Add(1);
            }

        }
        // the elevation points "grow"
        for (int dd3 = 0; dd3 < 10; dd3++)
        {

            growlistorigamount = elevationgrowlist.Count;
            for (int q = 0; q < growlistorigamount; q++)
            {
                if (tilelist[elevationgrowlist[q]] == 4 || tilelist[elevationgrowlist[q]] == 0 || tilelist[elevationgrowlist[q]] == 5 || tilelist[elevationgrowlist[q]] == 6 || tilelist[elevationgrowlist[q]] == 7 || tilelist[elevationgrowlist[q]] == 8 || tilelist[elevationgrowlist[q]] == 2)
                {
                    var offsetnum = 0;
                    if (Mathf.FloorToInt(elevationgrowlist[q] / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    var neighbors = findneighbors(elevationgrowlist[q], w, offsetnum);

                    for (int f = 0; f < neighbors.Length; f++)
                    {

                        if (neighbors[f] > 0 && neighbors[f] < w * h)
                        {

                            if (elevation[neighbors[f]] == 0)
                            {
                                //     print(elevationgrowlist[q]);
                                elevation[neighbors[f]] = elevation[elevationgrowlist[q]];
                                elevationgrowlist.Add(neighbors[f]);
                            }
                            else
                            {
                                //  print(elevation[neighbors[f]]);
                            }
                        }
                    }
                }
            }
        }
        // the resource points "grow"
        for (int ddd3 = 0; ddd3 < 3; ddd3++)
        {

            growlistorigamount = resgrowlist.Count;
            for (int q = 0; q < growlistorigamount; q++)
            {
                if (tilelist[resgrowlist[q]] == 4 || tilelist[resgrowlist[q]] == 0 || tilelist[resgrowlist[q]] == 5 || tilelist[resgrowlist[q]] == 6 || tilelist[resgrowlist[q]] == 7 || tilelist[resgrowlist[q]] == 8 || tilelist[resgrowlist[q]] == 2)
                {
                    var offsetnum = 0;
                    if (Mathf.FloorToInt(resgrowlist[q] / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    var neighbors = findneighbors(resgrowlist[q], w, offsetnum);

                    for (int f = 0; f < neighbors.Length; f++)
                    {

                        if (neighbors[f] > 0 && neighbors[f] < w * h)
                        {
                            if (reslist[neighbors[f]] == 0)
                            {
                                reslist[neighbors[f]] = reslist[resgrowlist[q]];
                                resgrowlist.Add(neighbors[f]);
                            }
                            else
                            {
                                //  print(elevation[neighbors[f]]);
                            }
                        }
                    }
                }
            }
        }
        // the natural objects and biomes "grow"
        for (int d3 = 0; d3 < 8; d3++)

        {

            growlistorigamount = growlist1.Count;
            for (int q = 0; q < growlistorigamount; q++)
            {
                if (tilelist[growlist1[q]] == 4 || tilelist[growlist1[q]] == 0 || tilelist[growlist1[q]] == 5 || tilelist[growlist1[q]] == 6 || tilelist[growlist1[q]] == 7 || tilelist[growlist1[q]] == 8)
                {
                    var offsetnum = 0;
                    if (Mathf.FloorToInt(growlist1[q] / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    var neighbors = findneighbors(growlist1[q], w, offsetnum);

                    for (int f = 0; f < neighbors.Length; f++)
                    {

                        if (neighbors[f] > 0 && neighbors[f] < w * h)
                        {

                            if (tilelist[neighbors[f]] == 3 || tilelist[neighbors[f]] == 1)
                            {

                                coastal = true;
                                coasts.Add(neighbors[f]);
                            }
                            else
                            {
                                island = false;
                            }

                            if (tilelist[neighbors[f]] == 2)
                            {

                                tilelist[neighbors[f]] = tilelist[growlist1[q]];


                                if (natobjlist[neighbors[f]] == 1)
                                {
                                    natobjlist[neighbors[f]] = natobjlist[growlist1[q]];
                                }

                                // growlist1.RemoveAt(q);
                                growlist1.Add(neighbors[f]);
                            }

                        }
                    }

                    /*
                    if (tilelist[growlist1[q]] == 0)
                    {
                        tilelist[growlist1[q]] = 2;
                    }
                    else if (tilelist[growlist1[q]] == 1)
                    {
                        tilelist[growlist1[q]] = 3;
                    }*/
                }
                // growlist1.RemoveAt(q);
            }

        }
        elevationgrowlist.Clear();
        // new points are added for elevation ,dont remember why lol
        for (int tw = 0; tw < w * h; tw++)
        {
            if (elevation[tw] == 1)
            {
                if (Random.Range(0, 10) == 5)
                {
                    elevation[tw] = 4;
                    elevationgrowlist.Add(tw);
                    natobjlist[tw] = 0;
                }
                else if (Random.Range(0, 10) < 4)
                {
                    elevation[tw] = 2;
                    elevationgrowlist.Add(tw);
                }
            }
        }
        for (int ddd3 = 0; ddd3 < 10; ddd3++)
        {

            growlistorigamount = elevationgrowlist.Count;
            for (int q = 0; q < growlistorigamount; q++)
            {
                if (tilelist[elevationgrowlist[q]] == 4 || tilelist[elevationgrowlist[q]] == 0 || tilelist[elevationgrowlist[q]] == 5 || tilelist[elevationgrowlist[q]] == 6 || tilelist[elevationgrowlist[q]] == 7 || tilelist[elevationgrowlist[q]] == 8 || tilelist[elevationgrowlist[q]] == 2)
                {
                    var offsetnum = 0;
                    if (Mathf.FloorToInt(elevationgrowlist[q] / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    var neighbors = findneighbors(elevationgrowlist[q], w, offsetnum);

                    for (int f = 0; f < neighbors.Length; f++)
                    {

                        if (neighbors[f] > 0 && neighbors[f] < w * h)
                        {
                            if (elevation[neighbors[f]] == 1)
                            {
                                //     print(elevationgrowlist[q]);
                                elevation[neighbors[f]] = elevation[elevationgrowlist[q]];
                                elevationgrowlist.Add(neighbors[f]);
                                if (elevation[neighbors[f]] == 4)
                                {
                                    natobjlist[neighbors[f]] = 0;
                                }
                            }

                        }
                    }
                }
            }
        }
        longrow = false;
        tilexcoord = 0.5f;
        tilezcoord = 0;
        // clouds are added everywhere above where land will be.
        for (int y = 0; y < w * h; y++)
        {
            if (longrow == false && tilexcoord >= w)
            {
                tilexcoord = 0;
                tilezcoord += 1;
                longrow = true;
            }
            else if (longrow == true && tilexcoord >= w)
            {
                tilexcoord = 0.5f;
                tilezcoord += 1;
                longrow = false;
            }
            var cloudtile = Instantiate(tileobjs[4], new Vector3(tilexcoord * 2, -1, tilezcoord * 1.74f), Quaternion.Euler(90, 0, 0));
            cloudtile.transform.localScale = new Vector3(1.16f, 1.16f, -10f);
            cloudslist.Add(cloudtile);
            if (tilexcoord < w / 4)
            {
                cloudsfirstmappart.Add(y);
            }
            else if (tilexcoord > w / 4 * 3)
            {
                cloudssecondmappart.Add(y);
            }
            tilexcoord += 1;
        }
        longrow = false;
        tilexcoord = 0.5f;
        tilezcoord = 0;
        var xcord = 0;
        var ycord = 0;
        spawnpoint = Random.Range(0, w * h);

        // a spawn point index is searched
        while (tilelist[spawnpoint] == 1 || tilelist[spawnpoint] == 3 || tilelist[spawnpoint] == 4 || elevation[spawnpoint] == 4)
        {
            spawnpoint = Random.Range(0, w * h);
        }
        // in this loop tiles, resources, natural objects are added.
        for (int s = 0; s < w * h; s++)
        {
            if (xcord > w)
            {
                ycord += 1;
                xcord = 0;
            }
            
            if (longrow == false && tilexcoord >= w)
            {
                tilexcoord = 0;
                tilezcoord += 1;
                longrow = true;
            }
            else if (longrow == true && tilexcoord >= w)
            {
                tilexcoord = 0.5f;
                tilezcoord += 1;
                longrow = false;
            }

            // from the spawnpoint index the coordinates are searched
            if (s == spawnpoint)
            {
                GetComponent<unitscript>().spawn(new Vector2(tilexcoord * 2, tilezcoord * 1.74f), spawnpoint);
            }
            everytile.Add(new List<GameObject>());
            if (tilelist[s] != 4 && tilelist[s] != 3 && tilelist[s] != 1)
            {

      

                // a hexagon is instantiated
                var newtile = Instantiate(tileobjs[tilelist[s]], new Vector3(tilexcoord * 2, 0, tilezcoord * 1.74f), Quaternion.Euler(90, 0, 0));
                if (elevation[s] < 2)
                {
                    newtile.transform.localScale = new Vector3(1.16f, 1.16f, 1.16f);


                }
                else
                {
                    // if the tile has elevation, the mesh becomes the mesh of a mountain or hill
                    newtile.GetComponent<MeshFilter>().mesh = tileobjs[8 + elevation[s] / 2].GetComponent<MeshFilter>().sharedMesh;
                    newtile.transform.localScale = new Vector3(1.16f, 1.16f, -0.8f);

                    //print("hill/mountain");
                }

                // the hexagon has the script tilescript in it, where information is stored.
                newtile.GetComponent<tilescript>().elevation = elevation[s];
                newtile.GetComponent<tilescript>().tiletype = tilelist[s];
                newtile.name = "tile";
                everytile[s].Add(newtile);
                newtile.GetComponent<tilescript>().weirdnum = s;
                //  newtile.GetComponent<Renderer>().material.color = Color.cyan;

                //resources are instantiated
                var lisämäärä = 0;
                if (reslist[s] > 0)
                {
                    if (elevation[s] != 4)
                    {
                        if (tilelist[s] > 6 && reslist[s] - 1 == 1)
                        {
                            lisämäärä = 1;
                        }
                        var resobj = Instantiate(resobjlist[reslist[s] - 1 - lisämäärä], new Vector3(tilexcoord * 2, newtile.transform.position.y, tilezcoord * 1.74f), Quaternion.Euler(270, 0, 0));
                        resobj.transform.localScale = new Vector3(1.16f, 1.16f, 1.16f);
                        if (elevation[s] - lisämäärä == 2)
                        {
                            resobj.transform.position += new Vector3(0, 0.5f, 0);
                        }
                        resobj.transform.SetParent(newtile.transform);
                        if (reslist[s] - 1 - lisämäärä == 0)
                        {
                            resobj.GetComponent<Renderer>().material.color = Color.yellow;
                        }
                        else
                        {
                            resobj.GetComponent<Renderer>().material.color = new Color(1, 0, 0.9f, 0);
                        }
                        newtile.GetComponent<tilescript>().res = reslist[s];
                    }
                }
                // naturalobjects are instantiated(forest,jungle)
                if (natobjlist[s] > 1)
                {
                    var natobj = Instantiate(natobjs[natobjlist[s]], new Vector3(tilexcoord * 2, newtile.transform.position.y, tilezcoord * 1.74f), Quaternion.Euler(270, 0, 0));
                    newtile.GetComponent<tilescript>().natobj = natobjlist[s];
                    natobj.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    if (elevation[s] == 2)
                    {
                        natobj.transform.position += new Vector3(0, 0.6f, 0);
                    }
                    natobj.transform.SetParent(newtile.transform);

                }

                newtile.GetComponent<tilescript>().updateres();
                //   }
                /*var offsetnum = 0;
                if (Mathf.FloorToInt(s / h) % 2 == 0)
                {
                    offsetnum = 1;
                }*/
                if (tilexcoord < w / 4)
                {
                    firstmappart.Add(s);
                }
                else if (tilexcoord > w / 4 * 3)
                {
                    secondmappart.Add(s);
                }



            }
            tilexcoord += 1;
            xcord += 1;
        }
        //rivers are added ******************WARNING*********************** SUPER CONFUSING(but works)

        //i won't comment everything here because it is pointless to even try to explain what happens here, but basically this is how it goes:
        //a tile is chosen, for that tile, 2 directions are chosen, where the river is coming from and where it is going.
        //a function in tilescript "calculates" the path of the river.
        // + a lot of weird stuff for stuff like adding freshwater bonus to tileyield for everything next to the river
        for (int b = 0; b < riverlist.Count; b++)
        {

            if (riverlist[b] == 0)
            {

                var offsetnum = 0;
                if (Mathf.FloorToInt(b / w) % 2 == 0)
                {
                    offsetnum = 1;
                }
                var neighbors = findneighbors(b, w, offsetnum);
                var startpoint = 0;
                var riverlength = -1;

                var endpoint = startpoint + 3;
                if (endpoint > 5)
                {
                    endpoint = startpoint - 3;
                }
                var testnum = endpoint + 1;
                if (testnum > 5)
                {
                    testnum = 0;
                }
                var testnum2 = testnum + 1;
                if (testnum2 > 5)
                {
                    testnum2 = 0;
                }
                var testnum3 = testnum2 + 1;
                if (testnum3 > 5)
                {
                    testnum3 = 0;
                }
                for (int r = 0; r < neighbors.Length; r++)
                {
                    if (neighbors[r] > 0 && neighbors[r] < w * h)
                    {
                        if (riverlist[neighbors[r]] == riverlength)
                        {
                            startpoint = r;
                        }

                        if (everytile[neighbors[r]].Count > 0 && (r == testnum || r == testnum2 || r == testnum3) && tilelist[neighbors[r]] != 1 && tilelist[neighbors[r]] != 3 && tilelist[neighbors[r]] != 4)
                        {
                            everytile[neighbors[r]][0].GetComponent<tilescript>().freshwater = true;
                            everytile[neighbors[r]][0].GetComponent<tilescript>().updateres();
                        }

                    }
                }

                //print(everytile[b][0].GetComponent<tilescript>().findriverroute(startpoint, -1, endpoint));
                /*  var espoint = startpoint + 3;

                      if (espoint > 5)
                      {
                          espoint = startpoint - 3;
                      }
                  */
                // print(b + "test" + everytile[b].Count);
                // print(elevation[b]);

                var nas = everytile[b][0].GetComponent<tilescript>().findriverroute(startpoint, -1, endpoint, riverlength, elevation[b]);
                var lastpoint = b;
                var nas2 = nas;
                for (int v = 0; v < Random.Range(1, w * h / 100) / 2; v++)
                {
                    riverlength += 1;
                    offsetnum = 0;
                    if (Mathf.FloorToInt(lastpoint / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    neighbors = findneighbors(lastpoint, w, offsetnum);

                    lastpoint = neighbors[endpoint];

                    startpoint = 0;
                    endpoint += Random.Range(-1, 2);

                    if (endpoint > 5)
                    {
                        endpoint = 0;
                    }
                    else if (endpoint < 0)
                    {
                        endpoint = 5;
                    }
                    testnum = endpoint + 1;
                    if (testnum > 5)
                    {
                        testnum = 0;
                    }
                    testnum2 = testnum + 1;
                    if (testnum2 > 5)
                    {
                        testnum2 = 0;
                    }
                    testnum3 = testnum2 + 1;
                    if (testnum3 > 5)
                    {
                        testnum3 = 0;
                    }
                    for (int r = 0; r < neighbors.Length; r++)
                    {
                        if (neighbors[r] > 0 && neighbors[r] < w * h)
                        {
                            //print(riverlist[neighbors[r]] + "d" + riverlength);
                            if (neighbors[r] == lastpoint)
                            {

                                startpoint = r + 3;
                                if (startpoint > 5)
                                {
                                    startpoint = r - 3;
                                }

                            }
                            if (everytile[neighbors[r]].Count > 0 && (r == testnum || r == testnum2 || r == testnum3) && tilelist[neighbors[r]] != 1 && tilelist[neighbors[r]] != 3 && tilelist[neighbors[r]] != 4)
                            {
                                everytile[neighbors[r]][0].GetComponent<tilescript>().freshwater = true;
                                everytile[neighbors[r]][0].GetComponent<tilescript>().updateres();
                                //print("here");
                            }
                        }
                    }

                    if (lastpoint > 0 && lastpoint < w * h && tilelist[lastpoint] != 1 && tilelist[lastpoint] != 3 && tilelist[lastpoint] != 4)
                    {
                        //  print(lastpoint + "test" + everytile[lastpoint].Count);
                        //  print(elevation[lastpoint]);
                        nas2 = everytile[lastpoint][0].GetComponent<tilescript>().findriverroute(startpoint, nas, endpoint, riverlength, elevation[lastpoint]);
                        nas = nas2;
                        //    everytile[lastpoint][0].transform.Translate(0, 0, 0.1f);
                    }





                }
                /*  for (int v = 0; v < 10; v++)
                  {




                      if (neighbors[endpoint] > 0 && neighbors[endpoint] < w * h && tilelist[neighbors[endpoint]] != 1 && tilelist[neighbors[endpoint]] != 3 && tilelist[neighbors[endpoint]] != 4)
                      {
                          nas2 = everytile[neighbors[endpoint]][0].GetComponent<tilescript>().findriverroute(startpoint, nas, endpoint, riverlength);
                          nas = nas2;
                      }
                      offsetnum = 0;
                      rotamount = Random.Range(-1, 2);
                      endpoint += Random.Range(-1, 2);

                      if (endpoint > 5)
                      {
                          endpoint = 0;
                      } else if (endpoint < 0)
                      {
                          endpoint = 5;
                      }
                     startpoint = endpoint + 3;
                      if (startpoint > 5)
                      {
                          startpoint = endpoint - 3;
                      }
                      if (Mathf.FloorToInt(neighbors[endpoint] / w) % 2 == 0)
                      {
                          offsetnum = 1;
                      }
                      neighbors = findneighbors(neighbors[endpoint], w, offsetnum);
                      //   riverlength += 1;
                  }*/
                /*for (int v = 0; v < 10; v++)
                {
                    var rivercurve = Random.Range(0, 6);
                    endpoint = startpoint + 3;
                    if (endpoint > 5)
                    {
                        endpoint = startpoint - 3;
                    }
                    riverlength += 1;
                    if (lastpoint > 0 && lastpoint < w * h && tilelist[lastpoint] != 1 && tilelist[lastpoint] != 3 && tilelist[lastpoint] != 4)
                    {
                        nas2 = everytile[lastpoint][0].GetComponent<tilescript>().findriverroute(startpoint, nas, endpoint, riverlength);
                        riverlist[lastpoint] = riverlength;
                        nas = nas2;

                    }
                    offsetnum = 0;
                    if (Mathf.FloorToInt(lastpoint / w) % 2 == 0)
                    {
                        offsetnum = 1;
                    }
                    neighbors = findneighbors(lastpoint, w, offsetnum);
                    lastpoint = neighbors[endpoint];
                    startpoint = 0;
                    for (int r = 0; r < neighbors.Length; r++)
                    {
                        if (neighbors[r] > 0 && neighbors[r] < w * h)
                        {
                           // print(riverlist[neighbors[r]] + "d" + riverlength);
                            if (riverlist[neighbors[r]] == riverlength)
                            {
                                //print(riverlength);
                                startpoint = r;
                            }
                        }
                    }

                }*/
            }

        }
        //GameObject.Find("Main Camera").GetComponent<Cameracontrols>().octa = gameObject;
        
       
        
    }
    // Update is called once per frame

        // if the player unit moves, this function clears the clouds from around him.
    public void clearclouds(int pos)
    {
        var offsetnum = 0;
        if (Mathf.FloorToInt(pos / width) % 2 == 0)
        {
            offsetnum = 1;
        }
        var neighbors = findneighbors(pos, width, offsetnum);
        cloudslist[pos].transform.Translate(0, 0, 100);
        cloudslist[pos].name = "dead";
        for (int e = 0; e < neighbors.Length; e++)
        {
            if (neighbors[e] >= 0 && neighbors[e] <= width * height)
            {
                cloudslist[neighbors[e]].transform.Translate(0, 0, 100);
                cloudslist[neighbors[e]].name = "dead";
            }
        }
        //tile yields from the discovered areas are revealed.
        GameObject.Find("Main Camera").GetComponent<Cameracontrols>().update = true;
    }
    void Update () {
		
	}
}

